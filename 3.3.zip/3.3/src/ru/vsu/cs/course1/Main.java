package ru.vsu.cs.course1;

import java.util.Comparator;

public class Main {

    public static void main(String[] args) {
        MyPriorityQueue<Integer> queue = new MyPriorityQueue<>(Comparator.comparing(Integer::new));
        MyPriorityQueue<Integer> q2 = new MyPriorityQueue<>(Comparator.comparing(Integer::new));
        queue.offer(4);
        queue.offer(2);
        queue.offer(7);
        queue.offer(3);
        queue.offer(6);
        int node,k=0, size=queue.size();
        int mas[] = new int [size];
        for (int i=0; i<size; i++)
        { node=queue.poll();
            System.out.println(node);
            if (node%2==0) {mas[k]=node;k++;}}
        for (int i=0; i<k; i++)
            queue.offer(mas[i]);
        System.out.println("Size: " + queue.size() + "; queue: " + queue);
      /*  System.out.println("Size: " + queue.size() + "; queue: " + queue);
        System.out.println("peek(): " + queue.peek());
        System.out.println("pool(): " + queue.poll() + "; queue: " + queue);
        System.out.println("pool(): " + queue.poll() + "; queue: " + queue);
        System.out.println("pool(): " + queue.poll() + "; queue: " + queue);
        System.out.println("pool(): " + queue.poll() + "; queue: " + queue);
        System.out.println("pool(): " + queue.poll() + "; queue: " + queue);
        System.out.println("pool(): " + queue.poll() + "; queue: " + queue);*/
    }
}
